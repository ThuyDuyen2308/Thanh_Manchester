CREATE DATABASE QuanLyQuanCafe;
GO
USE QuanLyQuanCafe;
GO
CREATE TABLE LoaiDoUong (
    MaLoai INT IDENTITY PRIMARY KEY,
    TenLoai NVARCHAR(100) NOT NULL
);
CREATE TABLE DoUong (
    MaDU INT IDENTITY PRIMARY KEY,
    TenDU NVARCHAR(150) NOT NULL,
    MaLoai INT NOT NULL,
    DonGia DECIMAL(18,0) NOT NULL,
    HinhAnh NVARCHAR(255),

    CONSTRAINT FK_DoUong_LoaiDoUong
        FOREIGN KEY (MaLoai)
        REFERENCES LoaiDoUong(MaLoai)
);
CREATE TABLE KhachHang (
    MaKH INT IDENTITY PRIMARY KEY,
    TenKH NVARCHAR(150),
    SDT VARCHAR(15),
    DiaChi NVARCHAR(255)
);
CREATE TABLE NhanVien (
    MaNV INT IDENTITY PRIMARY KEY,
    TenNV NVARCHAR(150) NOT NULL,
    MatKhau NVARCHAR(100) NOT NULL,
    SDT VARCHAR(15),
    DiaChi NVARCHAR(255)
);
CREATE TABLE Ban (
    MaBan INT IDENTITY PRIMARY KEY,
    SucChua INT NOT NULL,
    TrangThai NVARCHAR(50) NOT NULL
);
CREATE TABLE HoaDon (
    MaHD INT IDENTITY PRIMARY KEY,
    NgayLap DATETIME NOT NULL DEFAULT GETDATE(),
    MaNV INT NOT NULL,
    MaKH INT NULL,
    MaBan INT NOT NULL,
    TongTien DECIMAL(18,0),
    TrangThai NVARCHAR(50),

    CONSTRAINT FK_HoaDon_NhanVien
        FOREIGN KEY (MaNV)
        REFERENCES NhanVien(MaNV),

    CONSTRAINT FK_HoaDon_KhachHang
        FOREIGN KEY (MaKH)
        REFERENCES KhachHang(MaKH),

    CONSTRAINT FK_HoaDon_Ban
        FOREIGN KEY (MaBan)
        REFERENCES Ban(MaBan)
);
CREATE TABLE ChiTietHoaDon (
    MaHD INT NOT NULL,
    MaDU INT NOT NULL,
    SoLuong INT NOT NULL,
    DonGia DECIMAL(18,0) NOT NULL,
    ThanhTien AS (SoLuong * DonGia),

    CONSTRAINT PK_ChiTietHoaDon
        PRIMARY KEY (MaHD, MaDU),

    CONSTRAINT FK_CTHD_HoaDon
        FOREIGN KEY (MaHD)
        REFERENCES HoaDon(MaHD)
        ON DELETE CASCADE,

    CONSTRAINT FK_CTHD_DoUong
        FOREIGN KEY (MaDU)
        REFERENCES DoUong(MaDU)
);
